"use strict";
//------------------------------CREAZIONE TABELLA CON MODIFICA DEL DOM------------------------------//
//CREAZIONE DELLA TABELLA
Array.prototype.toTableDOM = function () {
    const table = document.createElement("table");
    const campi = getTRFirstDOM(this[0]);
    table.appendChild(campi);
    this.forEach(prodotto => {
        const tr = getTRDOM(prodotto);
        table.appendChild(tr);
    });
    //CREAZIONE DELLA CELLA
    function getTHDOM(content) {
        const th = document.createElement("th");
        const text = document.createTextNode(content);
        th.appendChild(text);
        return th;
    }
    //CREAZIONE DELLA RIGA
    function getTRDOM(oggetto) {
        const tr = document.createElement("tr");
        Object.keys(oggetto).forEach(property => {
            const th = getTHDOM(oggetto[property]);
            tr.appendChild(th);
        });
        return tr;
    }
    //CREAZIONE DELLA PRIMA RIGA [CON INTESTAZIONI]
    function getTRFirstDOM(oggetto) {
        const tr = document.createElement("tr");
        Object.keys(oggetto).forEach(property => {
            const th = getTHDOM(property.toUpperCase());
            th.setAttribute("style", "background-color: rgb(254, 255, 173)");
            tr.appendChild(th);
        });
        return tr;
    }
    return table;
};
//------------------------CREATE SELECT------------------------//
Array.prototype.toSelectBoxDOM = function (nome, value, textShown, intestazione = false, size = 1, multiple = false) {
    const select = document.createElement("select");
    select.id = nome;
    if (size != 1) {
        if (multiple) {
            select.setAttribute("multiple", "multiple");
        }
        select.size = size;
    }
    //inserisco campo vuoto
    if (intestazione) {
        const itemVuoto = {
            "categoryId": 0,
            "categoryName": "- scegliere -"
        };
        const optionFirst = getOptionDOM(itemVuoto, value, textShown);
        optionFirst.style.textAlign = "center";
        select.appendChild(optionFirst);
    }
    this.forEach(item => {
        const option = getOptionDOM(item, value, textShown);
        select.appendChild(option);
    });
    //////
    function getOptionDOM(oggetto, keyVal, content) {
        const option = document.createElement("option");
        if (Array.isArray(keyVal)) {
            var arrVal = [];
            keyVal.forEach(val => {
                arrVal.push(oggetto[val]);
            });
            option.value = arrVal.toString();
        }
        else {
            option.value = oggetto[keyVal];
        }
        const text = document.createTextNode(oggetto[content]);
        option.appendChild(text);
        return option;
    }
    return select;
};
HTMLSelectElement.prototype.sposta = function (selectDestinazione) {
    const optionSelezionate = this.selectedOptions;
    spostamento(optionSelezionate, this, selectDestinazione);
};
HTMLSelectElement.prototype.spostaAll = function (selectDestinazione) {
    const optionToMove = this.options;
    spostamento(optionToMove, this, selectDestinazione);
};
function spostamento(optionToMove, mittente, destinazione) {
    for (let i = 0; i < optionToMove.length; i++) {
        const opzione = optionToMove[i];
        mittente.removeChild(opzione);
        destinazione.appendChild(opzione);
    }
}
//------------------------------CREAZIONE TABELLA DEL CARRELLO------------------------------//
//CREAZIONE DELLA TABELLA
Array.prototype.toTableDOMCarrello = function () {
    const table = document.createElement("table");
    const campi = getTRFirstDOM(this[0]);
    table.appendChild(campi);
    this.forEach(prodotto => {
        const tr = getTRDOM(prodotto);
        table.appendChild(tr);
    });
    //CREAZIONE DELLA CELLA
    function getTHDOM(content) {
        const th = document.createElement("th");
        const text = document.createTextNode(content);
        th.style.textAlign = "center";
        th.appendChild(text);
        return th;
    }
    //CREAZIONE DELLA RIGA
    function getTRDOM(oggetto) {
        const tr = document.createElement("tr");
        Object.keys(oggetto).forEach(property => {
            if (["prodotto", "quantita", "prezzo"].includes(property)) {
                const th = getTHDOM(oggetto[property]);
                tr.appendChild(th);
            }
        });
        return tr;
    }
    //CREAZIONE DELLA PRIMA RIGA [CON INTESTAZIONI]
    function getTRFirstDOM(oggetto) {
        const tr = document.createElement("tr");
        Object.keys(oggetto).forEach(property => {
            if (["prodotto", "quantita", "prezzo"].includes(property)) {
                const th = getTHDOM(property.toUpperCase());
                th.setAttribute("style", "background-color: rgb(254, 255, 173)");
                tr.appendChild(th);
            }
        });
        return tr;
    }
    return table;
};
