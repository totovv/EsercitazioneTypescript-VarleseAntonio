"use strict";
String.prototype.capitalize = function () {
    var str = this.toLowerCase();
    const output = str.charAt(0).toUpperCase() + str.slice(1);
    return output;
};
String.prototype.inversa = function () {
    var output = "";
    for (let i = this.length - 1; i >= 0; i--) {
        output += this[i];
    }
    return output;
};
