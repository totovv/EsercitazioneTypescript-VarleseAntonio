var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import * as Helper from "../utils/helper.js";
import { FromFetch } from "../BL/mainPageBL.js";
import "../utils/helperDOM.js";
export var Visualizzazione;
(function (Visualizzazione) {
    function visualizzaProdotti(jsonProdotti) {
        const container = document.getElementById("containerProdotti");
        const divRow = document.createElement("div");
        divRow.className = "row";
        var conta = 0;
        jsonProdotti.forEach(product => {
            const contaImm = (conta % 6) + 1;
            conta++;
            const productDiv = getDivProdotto(product, contaImm);
            divRow.appendChild(productDiv);
        });
        container.appendChild(divRow);
    }
    Visualizzazione.visualizzaProdotti = visualizzaProdotti;
    function getDivProdotto(prodotto, conta) {
        const divCol = document.createElement("div");
        divCol.className = "col-12 col-md-6 col-lg-3 ";
        divCol.id = String(prodotto["productId"]);
        divCol.style.paddingLeft = "1vw";
        divCol.style.paddingRight = "1vw";
        divCol.style.marginTop = "2vh";
        divCol.style.marginBottom = "2vh";
        //IMMAGINE
        const immagine = document.createElement("img");
        immagine.src = `./images/${conta}.jpg`;
        immagine.style.width = "100%";
        const divImmagine = document.createElement("div");
        divImmagine.appendChild(immagine);
        divCol.appendChild(divImmagine);
        //CONTENUTO
        const divContenuto = document.createElement("div");
        divContenuto.style.padding = "0.5vw";
        divContenuto.style.overflow = "hidden";
        divContenuto.style.whiteSpace = "nowrap";
        //CONTENUTO-NOME
        const divNome = creaContenuto("Prodotto: ", prodotto["productName"], divContenuto);
        divNome.id = "nomeProdottoCard";
        divContenuto.appendChild(divNome);
        //CONTENUTO-PREZZO
        const divCosto = creaContenuto("Prezzo: ", prodotto["unitPrice"], divContenuto);
        divCosto.id = "costoProdottoCard";
        divContenuto.appendChild(divCosto);
        //CONTENUTO-UNITÀ IN STOCK
        const divUnita = creaContenuto("N. pezzi rimasti: ", prodotto["unitsInStock"], divContenuto);
        divUnita.id = "unitaProdottoCard";
        divContenuto.appendChild(divUnita);
        //CONTENUTO-ADD TO CART
        const divAdd = document.createElement("div");
        const addToCart = document.createElement("a");
        addToCart.href = "#" + prodotto["productId"];
        addToCart.id = "aggiungiProdottoCard";
        const textAdd = document.createTextNode("Aggiungi al carrello");
        addToCart.appendChild(textAdd);
        addToCart.onclick = function (event) {
            event.preventDefault();
            //QUI-------------------------------------------------------------
            aggiungiAlCarrello(prodotto["productId"], prodotto["productName"], 1, prodotto["unitPrice"]);
        };
        divAdd.appendChild(addToCart);
        divAdd.style.textAlign = "center";
        divContenuto.appendChild(divAdd);
        divContenuto.style.backgroundColor = "darkseagreen";
        divContenuto.style.maxWidth = "100%";
        divContenuto.style.maxHeight = "100%";
        divCol.appendChild(divContenuto);
        return divCol;
    }
    function creaContenuto(start, content, divContenuto) {
        const div = document.createElement("div");
        const textNome = document.createTextNode(start + content);
        div.appendChild(textNome);
        return div;
    }
    function visualizzaFiltroNome(divTipoFiltro) {
        const spanTextBase = document.getElementById("textBaseTop");
        spanTextBase.style.display = "block";
        const spanTextCarrello = document.getElementById("textCarrello");
        spanTextCarrello.style.display = "none";
        const inputLettera = document.createElement("input");
        inputLettera.type = "search";
        inputLettera.className = "form-control rounded";
        inputLettera.placeholder = "Iniziale prodotto";
        inputLettera.id = "inputLettera";
        const buttonCercaLettera = document.createElement("button");
        const buttonText = document.createTextNode("Cerca");
        buttonCercaLettera.appendChild(buttonText);
        buttonCercaLettera.id = "buttonLettera";
        divTipoFiltro.appendChild(inputLettera);
        divTipoFiltro.appendChild(buttonCercaLettera);
    }
    Visualizzazione.visualizzaFiltroNome = visualizzaFiltroNome;
    function visualizzaFiltroPrezzo(divTipoFiltro) {
        const spanTextBase = document.getElementById("textBaseTop");
        spanTextBase.style.display = "block";
        const spanTextCarrello = document.getElementById("textCarrello");
        spanTextCarrello.style.display = "none";
        const inputPrezzoMin = document.createElement("input");
        inputPrezzoMin.id = "prezzoMin";
        inputPrezzoMin.type = "number";
        inputPrezzoMin.placeholder = "min";
        inputPrezzoMin.min = "0";
        inputPrezzoMin.step = ".01";
        const inputPrezzoMax = document.createElement("input");
        inputPrezzoMax.id = "prezzoMax";
        inputPrezzoMax.type = "number";
        inputPrezzoMax.placeholder = "max";
        inputPrezzoMax.step = ".01";
        const span1 = document.createElement("span");
        const span1Text = document.createTextNode("-");
        span1.appendChild(span1Text);
        const buttonFiltroPrezzo = document.createElement("button");
        const buttonText = document.createTextNode("Filtra");
        buttonFiltroPrezzo.appendChild(buttonText);
        buttonFiltroPrezzo.id = "buttonPrezzo";
        divTipoFiltro.appendChild(inputPrezzoMin);
        divTipoFiltro.appendChild(span1);
        divTipoFiltro.appendChild(inputPrezzoMax);
        divTipoFiltro.appendChild(buttonFiltroPrezzo);
    }
    Visualizzazione.visualizzaFiltroPrezzo = visualizzaFiltroPrezzo;
    function visualizzaBoxCategorie(categorie) {
        const spanTextBase = document.getElementById("textBaseTop");
        spanTextBase.style.display = "block";
        const spanTextCarrello = document.getElementById("textCarrello");
        spanTextCarrello.style.display = "none";
        const boxCategorie = categorie.toSelectBoxDOM("categorie", "categoryId", "categoryName", true, 1, false);
        const box = document.getElementById("divTipoFiltro");
        box.appendChild(boxCategorie);
    }
    Visualizzazione.visualizzaBoxCategorie = visualizzaBoxCategorie;
    function visualizzaHome(jsonProdotti) {
        Helper.Varie.clear(document.getElementById("containerProdotti"));
        Helper.Varie.clear(document.getElementById("divTipoFiltro"));
        Visualizzazione.visualizzaProdotti(jsonProdotti);
        const spanTextBase = document.getElementById("textBaseTop");
        spanTextBase.style.display = "block";
        const spanTextCarrello = document.getElementById("textCarrello");
        spanTextCarrello.style.display = "none";
    }
    Visualizzazione.visualizzaHome = visualizzaHome;
    function visualizzaCarrello() {
        return __awaiter(this, void 0, void 0, function* () {
            Helper.Varie.clear(document.getElementById("containerProdotti"));
            Helper.Varie.clear(document.getElementById("divTipoFiltro"));
            const spanTextBase = document.getElementById("textBaseTop");
            spanTextBase.style.display = "none";
            const spanTextCarrello = document.getElementById("textCarrello");
            spanTextCarrello.style.display = "block";
            const tokenTest = sessionStorage.getItem('token');
            if (!tokenTest) {
                const responseLogin = FromFetch.login();
                const loginToken = yield responseLogin;
                sessionStorage.setItem("token", loginToken.toString());
            }
            const token = sessionStorage.getItem("token");
            const responseProdottiCarrello = FromFetch.getProdottiCarrello(String(token));
            const jsonProdottiCarrello = yield responseProdottiCarrello;
            const container = document.getElementById("containerProdotti");
            container.appendChild(jsonProdottiCarrello.toTableDOMCarrello());
        });
    }
    Visualizzazione.visualizzaCarrello = visualizzaCarrello;
    function aggiungiAlCarrello(idProdotto, nome, quantita, costo) {
        return __awaiter(this, void 0, void 0, function* () {
            const tokenTest = sessionStorage.getItem("token");
            if (!tokenTest) {
                const responseLogin = FromFetch.login();
                const loginToken = yield responseLogin;
                sessionStorage.setItem("token", loginToken.toString());
            }
            const token = sessionStorage.getItem("token");
            const data = {
                idCarrello: 0,
                idProdotto: idProdotto,
                prodotto: nome,
                quantita: quantita,
                prezzo: costo,
                cliente: token
            };
            console.log(data);
            const responsePost = yield FromFetch.postProdotto(data);
            alert(responsePost);
        });
    }
})(Visualizzazione || (Visualizzazione = {}));
;
