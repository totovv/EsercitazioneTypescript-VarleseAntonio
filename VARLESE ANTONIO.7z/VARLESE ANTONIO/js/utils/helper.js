export var Validazione;
(function (Validazione) {
    function isNumeric(input) {
        if (typeof input === 'number')
            return !isNaN(input) && isFinite(input);
        return typeof input === 'string' ? !isNaN(Number(input.replace(",", "."))) && input.trim() !== '' : false;
    }
    Validazione.isNumeric = isNumeric;
    function isNumericPositive(dato, includeZero = false) {
        let numero = Number(dato);
        return Validazione.isNumeric(dato) && includeZero ? numero >= 0 : numero > 0;
    }
    Validazione.isNumericPositive = isNumericPositive;
})(Validazione || (Validazione = {}));
export var Varie;
(function (Varie) {
    function clear(div) {
        if (div) {
            while (div.firstChild) {
                div.removeChild(div.firstChild);
            }
        }
    }
    Varie.clear = clear;
})(Varie || (Varie = {}));
