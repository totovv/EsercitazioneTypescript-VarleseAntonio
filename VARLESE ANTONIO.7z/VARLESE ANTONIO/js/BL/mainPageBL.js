var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import "../api/api.js";
import { API_CARRELLO, API_CATEGORIE, API_LOGIN, API_PRODOTTI } from "../api/api.js";
export var FromFetch;
(function (FromFetch) {
    function getCategorie() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield fetch(API_CATEGORIE)
                .then(response => response.json());
        });
    }
    FromFetch.getCategorie = getCategorie;
    function getProdotti() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield fetch(API_PRODOTTI)
                .then(response => response.json());
        });
    }
    FromFetch.getProdotti = getProdotti;
    function login() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield fetch(API_LOGIN, {
                method: "GET",
                headers: { "Authorization": "Bearer Varlese:Antonio" }
            })
                .then(response => response.json())
                .catch(error => alert(error));
        });
    }
    FromFetch.login = login;
    function getProdottiCarrello(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const url = API_CARRELLO + "/" + token;
            return yield fetch(url, {
                method: "GET",
                headers: { "Authorization": "Basic " + token }
            })
                .then(response => response.json())
                .catch(error => alert(error));
        });
    }
    FromFetch.getProdottiCarrello = getProdottiCarrello;
    function postProdotto(prodotto) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield fetch(API_PRODOTTI, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(prodotto),
            })
                .then(response => "Prodotto inserito correttamente")
                .catch(response => "Errore!");
        });
    }
    FromFetch.postProdotto = postProdotto;
})(FromFetch || (FromFetch = {}));
export var Filtri;
(function (Filtri) {
    function filtraArrayPerIniziale(filtro) {
        return __awaiter(this, void 0, void 0, function* () {
            const responseProdotti = FromFetch.getProdotti();
            const jsonProdotti = yield responseProdotti;
            return jsonProdotti.filter(obj => obj["productName"][0] == filtro.toUpperCase());
        });
    }
    Filtri.filtraArrayPerIniziale = filtraArrayPerIniziale;
    function filtraArrayPerPrezzo(min, max) {
        return __awaiter(this, void 0, void 0, function* () {
            const minNum = Number(min);
            const maxNum = Number(max);
            const responseProdotti = FromFetch.getProdotti();
            const jsonProdotti = yield responseProdotti;
            return jsonProdotti.filter(obj => (minNum <= obj["unitPrice"]) && (obj["unitPrice"] <= maxNum));
        });
    }
    Filtri.filtraArrayPerPrezzo = filtraArrayPerPrezzo;
    function filtraArrayPerCategoria(filtro) {
        return __awaiter(this, void 0, void 0, function* () {
            const responseProdotti = FromFetch.getProdotti();
            const jsonProdotti = yield responseProdotti;
            return jsonProdotti.filter(obj => obj["categoryId"] == filtro);
        });
    }
    Filtri.filtraArrayPerCategoria = filtraArrayPerCategoria;
})(Filtri || (Filtri = {}));
