var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import "../utils/helperDOM.js";
import * as Helper from "../utils/helper.js";
import { FromFetch } from "../BL/mainPageBL.js";
import { Filtri } from "../BL/mainPageBL.js";
import { Visualizzazione } from "../utils/helperVisualizzazioneProdotti.js";
(function () {
    window.addEventListener("DOMContentLoaded", () => {
        chiamataAsync();
    }, false);
    const chiamataAsync = () => __awaiter(this, void 0, void 0, function* () {
        try {
            //visualizzo tutti i prodotti
            const responseProdotti = FromFetch.getProdotti();
            const jsonProdotti = yield responseProdotti;
            Visualizzazione.visualizzaProdotti(jsonProdotti);
            //GESTIONE DEI FILTRI
            const divTipoFiltro = document.getElementById("divTipoFiltro");
            const filtraNomeLI = document.getElementById("filtraNome");
            const filtraPrezzoLI = document.getElementById("filtraPrezzo");
            const filtraCategoriaLI = document.getElementById("filtraCategoria");
            const homeAnchor = document.getElementById("home");
            homeAnchor.onclick = () => {
                Visualizzazione.visualizzaHome(jsonProdotti);
            };
            const carrelloAnchor = document.getElementById("carrello");
            carrelloAnchor.onclick = () => {
                Visualizzazione.visualizzaCarrello();
            };
            filtraNomeLI.onclick = function (event) {
                event.preventDefault();
                Helper.Varie.clear(divTipoFiltro);
                Visualizzazione.visualizzaFiltroNome(divTipoFiltro);
                Helper.Varie.clear(document.getElementById("containerProdotti"));
                Visualizzazione.visualizzaProdotti(jsonProdotti);
                const buttonCercaLettera = document.getElementById("buttonLettera");
                buttonCercaLettera.onclick = function () {
                    return __awaiter(this, void 0, void 0, function* () {
                        const letteraFiltroInput = document.getElementById("inputLettera");
                        const jsonProdottiFiltrato = yield Filtri.filtraArrayPerIniziale(letteraFiltroInput.value);
                        Helper.Varie.clear(document.getElementById("containerProdotti"));
                        Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                    });
                };
            };
            filtraPrezzoLI.onclick = function (event) {
                event.preventDefault();
                Helper.Varie.clear(divTipoFiltro);
                Visualizzazione.visualizzaFiltroPrezzo(divTipoFiltro);
                Helper.Varie.clear(document.getElementById("containerProdotti"));
                Visualizzazione.visualizzaProdotti(jsonProdotti);
                const buttonFiltraPrezzo = document.getElementById("buttonPrezzo");
                buttonFiltraPrezzo.onclick = function () {
                    return __awaiter(this, void 0, void 0, function* () {
                        const minInput = document.getElementById("prezzoMin");
                        const maxInput = document.getElementById("prezzoMax");
                        const jsonProdottiFiltrato = yield Filtri.filtraArrayPerPrezzo(minInput.value, maxInput.value);
                        Helper.Varie.clear(document.getElementById("containerProdotti"));
                        Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                    });
                };
            };
            filtraCategoriaLI.onclick = function () {
                return __awaiter(this, void 0, void 0, function* () {
                    try {
                        //PRENDO E VISUALIZZO LE CATEGORIE
                        const responseCategorie = FromFetch.getCategorie();
                        const jsonCategorie = yield responseCategorie;
                        Helper.Varie.clear(divTipoFiltro);
                        Visualizzazione.visualizzaBoxCategorie(jsonCategorie);
                        Helper.Varie.clear(document.getElementById("containerProdotti"));
                        Visualizzazione.visualizzaProdotti(jsonProdotti);
                        divTipoFiltro.onchange = function () {
                            return __awaiter(this, void 0, void 0, function* () {
                                //PRENDO E VISUALIZZO I PRODOTTI IN BASE ALLA CATEGORIA
                                const selectCategorie = document.getElementById("categorie");
                                const jsonProdottiFiltrato = yield Filtri.filtraArrayPerCategoria(selectCategorie.value);
                                Helper.Varie.clear(document.getElementById("containerProdotti"));
                                Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                            });
                        };
                    }
                    catch (errore) {
                        if (errore instanceof Error) {
                            alert(errore.message);
                        }
                    }
                });
            };
            //GESTIONE DEL CARRELLO
        }
        catch (errore) {
            if (errore instanceof Error) {
                alert(errore.message);
            }
        }
    });
})();
//sessionStorage.setItem("token", ...)
//const token = localStorage.getItem('token')
//sessionStorage.setItem("token", token)
//INSERIRE VALIDAZIONE DEI FILTRI
//I FILTRI DEVONO ESSERE GIÀ CREATI, POI VISUALIZZATI, NON DEVO CREARLI NUOVAMENTE AD OGNI CHIAMATA
//DUNQUE CREARLI NELL'HTML, I CLICK DEI TIPIFILTRI DEVONO SOLO VISUALIZZARLI E NON GESTIRLI, GESTIONE APPARTE
//QUANDO VISUALIZZATI DIVENTANO REQUIRED GLI INPUT
//CREARE COSTANTE containerProdotti E RICHIAMARLA NEI CLEAR
