var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import "../utils/helperDOM.js";
import * as Helper from "../utils/helper.js";
import { FromFetch } from "../BL/mainPageBL.js";
import { Visualizzazione } from "../utils/helperVisualizzazioneProdotti.js";
(function () {
    window.addEventListener("DOMContentLoaded", () => {
        chiamataAsync();
    }, false);
    const chiamataAsync = () => __awaiter(this, void 0, void 0, function* () {
        try {
            //PRENDO E VISUALIZZO LE CATEGORIE
            const responseCategorie = FromFetch.getCategorie();
            const jsonCategorie = yield responseCategorie;
            visualizzaBoxCategorie(jsonCategorie);
            //mostro prima tutti i prodotti
            const responseProdotti = FromFetch.getProdotti("");
            const jsonProdotti = yield responseProdotti;
            Visualizzazione.visualizzaProdotti(jsonProdotti);
            //da qui in poi visualizzerò solo i prodotti filtrati per categoria
            const divCategorie = document.getElementById("boxCategorie");
            divCategorie.onchange = function () {
                return __awaiter(this, void 0, void 0, function* () {
                    //PRENDO E VISUALIZZO I PRODOTTI IN BASE ALLA CATEGORIA
                    const selectCategorie = document.getElementById("categorie");
                    const responseProdotti = FromFetch.getProdotti(selectCategorie.value);
                    const jsonProdotti = yield responseProdotti;
                    Helper.Varie.clear(document.getElementById("containerProdotti"));
                    Visualizzazione.visualizzaProdotti(jsonProdotti);
                });
            };
        }
        catch (errore) {
            if (errore instanceof Error) {
                alert(errore.message);
            }
        }
    });
    function visualizzaBoxCategorie(categorie) {
        const boxCategorie = categorie.toSelectBoxDOM("categorie", "categoryId", "categoryName", true, 1, false);
        const box = document.getElementById("boxCategorie");
        box.appendChild(boxCategorie);
    }
})();
