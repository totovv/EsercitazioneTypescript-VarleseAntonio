import "../utils/helperDOM.js";
import * as Helper from "../utils/helper.js";
import { FromFetch } from "../BL/mainPageBL.js";
import { Filtri } from "../BL/mainPageBL.js";
import { ProdottoWithID } from "../MODELLI/modelliProdotto.js";
import { Categoria } from "../MODELLI/modelliProdotto.js";
import { Visualizzazione } from "../utils/helperVisualizzazioneProdotti.js";

(function () {

    window.addEventListener("DOMContentLoaded", () => {

        chiamataAsync();

    }, false);

    const chiamataAsync = async () => {
        try {
            //visualizzo tutti i prodotti
            const responseProdotti: Promise<ProdottoWithID[]> = FromFetch.getProdotti();
            const jsonProdotti: ProdottoWithID[] = await responseProdotti;
            Visualizzazione.visualizzaProdotti(jsonProdotti);

            //GESTIONE DEI FILTRI
            const divTipoFiltro: HTMLDivElement = document.getElementById("divTipoFiltro") as HTMLDivElement;

            const filtraNomeLI: HTMLLIElement = document.getElementById("filtraNome") as HTMLLIElement;
            const filtraPrezzoLI: HTMLLIElement = document.getElementById("filtraPrezzo") as HTMLLIElement;
            const filtraCategoriaLI: HTMLLIElement = document.getElementById("filtraCategoria") as HTMLLIElement;

            const homeAnchor: HTMLAnchorElement = document.getElementById("home") as HTMLAnchorElement;
            homeAnchor.onclick = () => {
                Visualizzazione.visualizzaHome(jsonProdotti);
            }

            const carrelloAnchor: HTMLAnchorElement = document.getElementById("carrello") as HTMLAnchorElement;
            carrelloAnchor.onclick = () => {
                Visualizzazione.visualizzaCarrello();
            }

            filtraNomeLI.onclick = function (event) {
                event.preventDefault();
                Helper.Varie.clear(divTipoFiltro);
                Visualizzazione.visualizzaFiltroNome(divTipoFiltro);

                Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                Visualizzazione.visualizzaProdotti(jsonProdotti);

                const buttonCercaLettera: HTMLButtonElement = document.getElementById("buttonLettera") as HTMLButtonElement;

                buttonCercaLettera.onclick = async function () {
                    const letteraFiltroInput: HTMLInputElement = document.getElementById("inputLettera") as HTMLInputElement;
                    const jsonProdottiFiltrato: ProdottoWithID[] = await Filtri.filtraArrayPerIniziale(letteraFiltroInput.value);
                    Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                    Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                }
            }

            filtraPrezzoLI.onclick = function (event) {
                event.preventDefault();
                Helper.Varie.clear(divTipoFiltro);
                Visualizzazione.visualizzaFiltroPrezzo(divTipoFiltro);

                Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                Visualizzazione.visualizzaProdotti(jsonProdotti);

                const buttonFiltraPrezzo: HTMLButtonElement = document.getElementById("buttonPrezzo") as HTMLButtonElement;

                buttonFiltraPrezzo.onclick = async function () {
                    const minInput: HTMLInputElement = document.getElementById("prezzoMin") as HTMLInputElement;
                    const maxInput: HTMLInputElement = document.getElementById("prezzoMax") as HTMLInputElement;

                    const jsonProdottiFiltrato: ProdottoWithID[] = await Filtri.filtraArrayPerPrezzo(minInput.value, maxInput.value);
                    Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                    Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                }
            }

            filtraCategoriaLI.onclick = async function () {
                try {
                    //PRENDO E VISUALIZZO LE CATEGORIE
                    const responseCategorie: Promise<Categoria[]> = FromFetch.getCategorie();
                    const jsonCategorie: Categoria[] = await responseCategorie;
                    Helper.Varie.clear(divTipoFiltro)
                    Visualizzazione.visualizzaBoxCategorie(jsonCategorie)

                    Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                    Visualizzazione.visualizzaProdotti(jsonProdotti);

                    divTipoFiltro.onchange = async function () {
                        //PRENDO E VISUALIZZO I PRODOTTI IN BASE ALLA CATEGORIA
                        const selectCategorie: HTMLSelectElement = document.getElementById("categorie") as HTMLSelectElement;

                        const jsonProdottiFiltrato: ProdottoWithID[] = await Filtri.filtraArrayPerCategoria(selectCategorie.value);

                        Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement)
                        Visualizzazione.visualizzaProdotti(jsonProdottiFiltrato);
                    }
                }
                catch (errore) {
                    if (errore instanceof Error) {
                        alert(errore.message);
                    }
                }
            }

            //GESTIONE DEL CARRELLO



        }
        catch (errore) {
            if (errore instanceof Error) {
                alert(errore.message);
            }
        }
    }



})();

//sessionStorage.setItem("token", ...)

//const token = localStorage.getItem('token')

//sessionStorage.setItem("token", token)






//INSERIRE VALIDAZIONE DEI FILTRI

//I FILTRI DEVONO ESSERE GIÀ CREATI, POI VISUALIZZATI, NON DEVO CREARLI NUOVAMENTE AD OGNI CHIAMATA
//DUNQUE CREARLI NELL'HTML, I CLICK DEI TIPIFILTRI DEVONO SOLO VISUALIZZARLI E NON GESTIRLI, GESTIONE APPARTE
//QUANDO VISUALIZZATI DIVENTANO REQUIRED GLI INPUT

//CREARE COSTANTE containerProdotti E RICHIAMARLA NEI CLEAR
