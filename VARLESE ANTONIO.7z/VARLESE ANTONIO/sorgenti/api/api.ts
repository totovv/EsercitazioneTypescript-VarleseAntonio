
export const API_PRODOTTI = "http://82.59.202.23/northwindwebapi/api/prodotti";
export const API_CATEGORIE = "http://82.59.202.23/northwindwebapi/api/categorie";
export const API_LOGIN = "http://82.59.202.23/northwindwebapi/api/login";
export const API_CARRELLO = "http://82.59.202.23/northwindwebapi/api/Carrello";

