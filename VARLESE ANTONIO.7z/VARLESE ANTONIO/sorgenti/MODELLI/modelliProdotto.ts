export interface Prodotto {
    productName: string,
    unitPrice: number,
    unitsInStock: number,
    discontinued: boolean,
    categoryId: number
}

export interface ProdottoWithID extends Prodotto{
    productId: number
}

export interface Categoria {
    categoryId: number, 
    categoryName: string
}

export interface ProdottoCarrello {
    idCarrello: number,
    idProdotto: number,
    prodotto: string,
    quantita: number,
    prezzo: number,
    cliente: string
}
