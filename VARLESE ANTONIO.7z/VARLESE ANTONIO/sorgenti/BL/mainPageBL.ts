import "../api/api.js"
import { API_CARRELLO, API_CATEGORIE, API_LOGIN, API_PRODOTTI } from "../api/api.js";
import { ProdottoWithID } from "../MODELLI/modelliProdotto.js";
import { Categoria } from "../MODELLI/modelliProdotto.js";
import { ProdottoCarrello } from "../MODELLI/modelliProdotto.js";

export namespace FromFetch {

    export async function getCategorie(): Promise<Categoria[]> {
        return await fetch(API_CATEGORIE)
            .then(response => response.json())
    }

    export async function getProdotti(): Promise<ProdottoWithID[]> {

        return await fetch(API_PRODOTTI)
            .then(response => response.json())
    }

    export async function login(): Promise<string> {

        return await fetch(API_LOGIN, {
            method: "GET",
            headers: { "Authorization": "Bearer Varlese:Antonio" }
        })
            .then(response => response.json())
            .catch(error => alert(error))
    }

    export async function getProdottiCarrello(token: string): Promise<ProdottoCarrello[]> {
        const url = API_CARRELLO + "/" + token;

        return await fetch(url, {
            method: "GET",
            headers: { "Authorization": "Basic " + token }
        })
            .then(response => response.json())
            .catch(error => alert(error))
    }

    export async function postProdotto(prodotto: ProdottoCarrello): Promise<string> {

        return await fetch(API_PRODOTTI, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(prodotto),
        })
            .then(response => "Prodotto inserito correttamente")
            .catch(response => "Errore!")
    }

}

export namespace Filtri {

    export async function filtraArrayPerIniziale(filtro: string): Promise<ProdottoWithID[]> {
        const responseProdotti: Promise<ProdottoWithID[]> = FromFetch.getProdotti();
        const jsonProdotti: ProdottoWithID[] = await responseProdotti;
        return jsonProdotti.filter(obj => obj["productName"][0] == filtro.toUpperCase());
    }

    export async function filtraArrayPerPrezzo(min: string, max: string): Promise<ProdottoWithID[]> {
        const minNum: number = Number(min);
        const maxNum: number = Number(max);
        const responseProdotti: Promise<ProdottoWithID[]> = FromFetch.getProdotti();
        const jsonProdotti: ProdottoWithID[] = await responseProdotti;
        return jsonProdotti.filter(obj => (minNum <= obj["unitPrice"]) && (obj["unitPrice"] <= maxNum));
    }

    export async function filtraArrayPerCategoria(filtro: string | number): Promise<ProdottoWithID[]> {
        const responseProdotti: Promise<ProdottoWithID[]> = FromFetch.getProdotti();
        const jsonProdotti: ProdottoWithID[] = await responseProdotti;
        return jsonProdotti.filter(obj => obj["categoryId"] == filtro);
    }

}





