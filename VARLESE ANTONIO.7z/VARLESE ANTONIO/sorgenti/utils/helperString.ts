
interface String {
    inversa(): string;
    capitalize(): string;
}

String.prototype.capitalize = function () {
    var str: string = this.toLowerCase();
    const output: string = str.charAt(0).toUpperCase() + str.slice(1);
    return output;
};

String.prototype.inversa = function () {
    var output: string = "";
    for (let i: number = this.length - 1; i >= 0; i--) {
        output += this[i];
    }
    return output;
};
