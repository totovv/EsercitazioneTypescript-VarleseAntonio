import { ProdottoWithID } from "../MODELLI/modelliProdotto.js";
import { Categoria } from "../MODELLI/modelliProdotto.js";
import { ProdottoCarrello } from "../MODELLI/modelliProdotto.js";
import * as Helper from "../utils/helper.js";
import { FromFetch } from "../BL/mainPageBL.js";
import "../utils/helperDOM.js";

export namespace Visualizzazione {

    export function visualizzaProdotti(jsonProdotti: ProdottoWithID[]): void {

        const container: HTMLDivElement = document.getElementById("containerProdotti") as HTMLDivElement;

        const divRow: HTMLDivElement = document.createElement("div") as HTMLDivElement;
        divRow.className = "row";

        var conta: number = 0;
        jsonProdotti.forEach(product => {
            const contaImm: number = (conta % 6) + 1;
            conta++;

            const productDiv: HTMLDivElement = getDivProdotto(product, contaImm);

            divRow.appendChild(productDiv);
        })
        container.appendChild(divRow);
    }

    function getDivProdotto(prodotto: ProdottoWithID, conta: number): HTMLDivElement {

        const divCol: HTMLDivElement = document.createElement("div") as HTMLDivElement;
        divCol.className = "col-12 col-md-6 col-lg-3 ";
        divCol.id = String(prodotto["productId"]);
        divCol.style.paddingLeft = "1vw";
        divCol.style.paddingRight = "1vw";
        divCol.style.marginTop = "2vh";
        divCol.style.marginBottom = "2vh";

        //IMMAGINE
        const immagine: HTMLImageElement = document.createElement("img") as HTMLImageElement;
        immagine.src = `./images/${conta}.jpg`;
        immagine.style.width = "100%";
        const divImmagine: HTMLDivElement = document.createElement("div") as HTMLDivElement;
        divImmagine.appendChild(immagine);
        divCol.appendChild(divImmagine);

        //CONTENUTO
        const divContenuto: HTMLDivElement = document.createElement("div") as HTMLDivElement;
        divContenuto.style.padding = "0.5vw";
        divContenuto.style.overflow = "hidden";
        divContenuto.style.whiteSpace = "nowrap";

        //CONTENUTO-NOME
        const divNome: HTMLDivElement = creaContenuto("Prodotto: ", prodotto["productName"], divContenuto);
        divNome.id = "nomeProdottoCard";
        divContenuto.appendChild(divNome);

        //CONTENUTO-PREZZO
        const divCosto: HTMLDivElement = creaContenuto("Prezzo: ", prodotto["unitPrice"], divContenuto);
        divCosto.id = "costoProdottoCard";
        divContenuto.appendChild(divCosto);

        //CONTENUTO-UNITÀ IN STOCK
        const divUnita: HTMLDivElement = creaContenuto("N. pezzi rimasti: ", prodotto["unitsInStock"], divContenuto);
        divUnita.id = "unitaProdottoCard";
        divContenuto.appendChild(divUnita);

        //CONTENUTO-ADD TO CART
        const divAdd = document.createElement("div");
        const addToCart = document.createElement("a");
        addToCart.href = "#" + prodotto["productId"];
        addToCart.id = "aggiungiProdottoCard";
        const textAdd = document.createTextNode("Aggiungi al carrello");
        addToCart.appendChild(textAdd);

        addToCart.onclick = function (event) {
            event.preventDefault();
            //QUI-------------------------------------------------------------
            aggiungiAlCarrello(prodotto["productId"], prodotto["productName"], 1, prodotto["unitPrice"]);
        }

        divAdd.appendChild(addToCart);
        divAdd.style.textAlign = "center";
        divContenuto.appendChild(divAdd);



        divContenuto.style.backgroundColor = "darkseagreen";
        divContenuto.style.maxWidth = "100%";
        divContenuto.style.maxHeight = "100%";
        divCol.appendChild(divContenuto);

        return divCol;
    }

    function creaContenuto(start: string, content: string | number, divContenuto: HTMLDivElement): HTMLDivElement {
        const div: HTMLDivElement = document.createElement("div") as HTMLDivElement;
        const textNome = document.createTextNode(start + content);
        div.appendChild(textNome);
        return div;
    }

    export function visualizzaFiltroNome(divTipoFiltro: HTMLDivElement): void {
        const spanTextBase: HTMLSpanElement = document.getElementById("textBaseTop") as HTMLSpanElement;
        spanTextBase.style.display = "block";
        const spanTextCarrello: HTMLSpanElement = document.getElementById("textCarrello") as HTMLSpanElement;
        spanTextCarrello.style.display = "none";

        const inputLettera = document.createElement("input");
        inputLettera.type = "search";
        inputLettera.className = "form-control rounded";
        inputLettera.placeholder = "Iniziale prodotto";
        inputLettera.id = "inputLettera";

        const buttonCercaLettera = document.createElement("button");
        const buttonText = document.createTextNode("Cerca");
        buttonCercaLettera.appendChild(buttonText);
        buttonCercaLettera.id = "buttonLettera";

        divTipoFiltro.appendChild(inputLettera);
        divTipoFiltro.appendChild(buttonCercaLettera);
    }

    export function visualizzaFiltroPrezzo(divTipoFiltro: HTMLDivElement): void {
        const spanTextBase: HTMLSpanElement = document.getElementById("textBaseTop") as HTMLSpanElement;
        spanTextBase.style.display = "block";
        const spanTextCarrello: HTMLSpanElement = document.getElementById("textCarrello") as HTMLSpanElement;
        spanTextCarrello.style.display = "none";

        const inputPrezzoMin = document.createElement("input");
        inputPrezzoMin.id = "prezzoMin";
        inputPrezzoMin.type = "number";
        inputPrezzoMin.placeholder = "min";
        inputPrezzoMin.min = "0";
        inputPrezzoMin.step = ".01";

        const inputPrezzoMax = document.createElement("input");
        inputPrezzoMax.id = "prezzoMax";
        inputPrezzoMax.type = "number";
        inputPrezzoMax.placeholder = "max";
        inputPrezzoMax.step = ".01";

        const span1: HTMLSpanElement = document.createElement("span");
        const span1Text = document.createTextNode("-");
        span1.appendChild(span1Text);

        const buttonFiltroPrezzo = document.createElement("button");
        const buttonText = document.createTextNode("Filtra");
        buttonFiltroPrezzo.appendChild(buttonText);
        buttonFiltroPrezzo.id = "buttonPrezzo";

        divTipoFiltro.appendChild(inputPrezzoMin);
        divTipoFiltro.appendChild(span1);
        divTipoFiltro.appendChild(inputPrezzoMax);
        divTipoFiltro.appendChild(buttonFiltroPrezzo);

    }

    export function visualizzaBoxCategorie(categorie: Categoria[]): void {
        const spanTextBase: HTMLSpanElement = document.getElementById("textBaseTop") as HTMLSpanElement;
        spanTextBase.style.display = "block";
        const spanTextCarrello: HTMLSpanElement = document.getElementById("textCarrello") as HTMLSpanElement;
        spanTextCarrello.style.display = "none";

        const boxCategorie: HTMLSelectElement = categorie.toSelectBoxDOM("categorie", "categoryId", "categoryName", true, 1, false);
        const box: HTMLDivElement = document.getElementById("divTipoFiltro") as HTMLDivElement;
        box.appendChild(boxCategorie);
    }

    export function visualizzaHome(jsonProdotti: ProdottoWithID[]): void {
        Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement);
        Helper.Varie.clear(document.getElementById("divTipoFiltro") as HTMLDivElement);
        Visualizzazione.visualizzaProdotti(jsonProdotti);
        const spanTextBase: HTMLSpanElement = document.getElementById("textBaseTop") as HTMLSpanElement;
        spanTextBase.style.display = "block";
        const spanTextCarrello: HTMLSpanElement = document.getElementById("textCarrello") as HTMLSpanElement;
        spanTextCarrello.style.display = "none";
    }

    export async function visualizzaCarrello(): Promise<void> {
        Helper.Varie.clear(document.getElementById("containerProdotti") as HTMLDivElement);
        Helper.Varie.clear(document.getElementById("divTipoFiltro") as HTMLDivElement);
        const spanTextBase: HTMLSpanElement = document.getElementById("textBaseTop") as HTMLSpanElement;
        spanTextBase.style.display = "none";
        const spanTextCarrello: HTMLSpanElement = document.getElementById("textCarrello") as HTMLSpanElement;
        spanTextCarrello.style.display = "block";

        const tokenTest: string | null = sessionStorage.getItem('token');
        
        if (!tokenTest) {
            const responseLogin: Promise<string> = FromFetch.login();
            const loginToken: string = await responseLogin;

            sessionStorage.setItem("token", loginToken.toString());
        }

        const token: string |null = sessionStorage.getItem("token");

        const responseProdottiCarrello: Promise<ProdottoCarrello[]> = FromFetch.getProdottiCarrello(String(token));
        const jsonProdottiCarrello: ProdottoCarrello[] = await responseProdottiCarrello;

        const container: HTMLDivElement = document.getElementById("containerProdotti") as HTMLDivElement;
        container.appendChild(jsonProdottiCarrello.toTableDOMCarrello())
    }

    async function aggiungiAlCarrello(idProdotto: number, nome: string, quantita: number, costo: number): Promise<void> {

        const tokenTest: string | null = sessionStorage.getItem("token");
        
        if (!tokenTest) {
            const responseLogin: Promise<string> = FromFetch.login();
            const loginToken: string = await responseLogin;

            sessionStorage.setItem("token", loginToken.toString());
        }

        const token: string |null = sessionStorage.getItem("token");

        const data: ProdottoCarrello = {
            idCarrello: 0,
            idProdotto: idProdotto,
            prodotto: nome,
            quantita: quantita,
            prezzo: costo,
            cliente: token
        } as ProdottoCarrello;

        const responsePost: string = await FromFetch.postProdotto(data);
        alert(responsePost);

    }

};





