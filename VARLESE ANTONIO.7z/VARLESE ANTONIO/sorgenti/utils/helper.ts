
export namespace Validazione {

  export function isNumeric(input: string | number): boolean {
    if (typeof input === 'number') return !isNaN(input) && isFinite(input);
    return typeof input === 'string' ? !isNaN(Number(input.replace(",", "."))) && input.trim() !== '' : false;
  }

  export function isNumericPositive(dato: string | number, includeZero = false): boolean {
    let numero: number = Number(dato);
    return Validazione.isNumeric(dato) && includeZero ? numero >= 0 : numero > 0;
  }

}

export namespace Varie {

  export function clear(div: HTMLDivElement): void {
    if (div) {
      while (div.firstChild) {
        div.removeChild(div.firstChild);
      }
    }
  }

}